#pragma strict
//Bullet Script

//Inspector variables
var bulletSpeed : float = 5.0;				//bullet movement speed - units per second

//Private variables

function Start () {

}

function Update () {

	//move the bullet in Y direction
	transform.Translate (0, bulletSpeed * Time.deltaTime, 0);
	
	//destroy the bullet after he gets out of the screen
	if (transform.position.y >= 6.5) {									//check if bullet get to his destroy position
	
		Destroy (gameObject);
	
	}

}

function OnTriggerEnter (other : Collider) {				//check for collision

	if (other.transform.tag == "asteroid") {					//check other object tag
	
		Destroy (gameObject);												//destroy the bullet
	
	}
	
		if (other.transform.tag == "block") {						//check other object tag
	
		Destroy (gameObject);												//destroy the boolet
	
	}

}