#pragma strict
//Win Scene Script

//Inspector variables
static var totalScore : int;

//Private variables

function Awake () {
	
}

function Start () {
	totalScore += scriptGameManager.gameScore; 				//wotks with static variables
}

function Update () {
	//Debug.Log (levelScore.length);
	
}

function OnGUI () {
	//GUI Group with Box the same dimentions as the group, buttons for main menu, restart and next level, score and total score
	GUI.BeginGroup (Rect (Screen.width / 2 - 130, Screen.height / 2 - 100, 260, 200));
	GUI.Box (Rect (0, 0, 260, 100), "YOU WIN!!!");
	//GUI.Label (Rect (25, 35, 200, 20), "Level Score: " + PlayerPrefs.GetInt ("SCORE"));
	GUI.Label (Rect (25, 35, 200, 20), "Level Score: " + scriptGameManager.gameScore);
	GUI.Label (Rect (25, 55, 200, 20), "Total Score: " + totalScore);
	if (GUI.Button (Rect (10, 105, 75, 30), "Main Menu")) {					//load the main menu - if clicked betwen levels start form level1 after the 3 levesls start form level1
		Application.LoadLevel ("sceneScreenMainMenu");
	}
	
	if (GUI.Button (Rect (90, 105, 75, 30), "Restart")) {								//restart the level that was play
		Application.LoadLevel (PlayerPrefs.GetInt ("LEVELS") -1);				//subtract -1 from the number saved in PlayerPrefs LEVELS to play last played level (managet by index in buld settings)
		totalScore -= scriptGameManager.gameScore;								//reset the score to the current score for restart
	}
	
	if (PlayerPrefs.GetInt ("LEVELS") <= 3) {													//dysplay the next level buttons only if the number of PlayerPrefs is 3 or smaller than 3 -  after level 3 buttons is not created
		if (GUI.Button (Rect (170, 105, 75, 30), "Next Level")) {
			Application.LoadLevel("sceneScreenLoadScreen");
		}
	}
	
	
	GUI.EndGroup ();
}