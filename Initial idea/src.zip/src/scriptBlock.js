#pragma strict
//Block Script

//Inspector variables
var blockSpeed : float = 5.0;						//block speed - units per second
var blockLives : int = 2;									//number of hits to kill the block
var colorOriginal : Color;								//original color of the block
var colorHited : Color;									//hited color of the block
var audioBlockExplosion : AudioClip;		//block explosion audio
var audioBlockHit : AudioClip;					//block hit audio
var particleExplosionBlock : Transform;	//explosion particle system
static var scoreBlock : int = 200;					//when block destroyed give score points


//Private variables
private var blockLivesReset : int;

function Start () {

	transform.position.x = Random.Range (-7.5, 7.5);					//call before Update() and give the object random X position
	
	blockLivesReset = blockLives;															//make block lives on start to be equal to blockLives

}

function Update () {

	//move the block down in Y
	transform.Translate (Vector3.down * blockSpeed * Time.deltaTime);
	
	//reset block from bottom to top position
	if (transform.position.y <= -7) {													//check if the object position is past botom position
	
		BlockReset ();
	
	}

}

function OnTriggerEnter (other : Collider) {							//check for collision

	if (other.transform.tag == "bullet") {									//compare collided object tag
	
		blockLives -=1;																		//subtract -1 of the block lives on every collision
		
		audio.clip = audioBlockHit;													//assign audio clip to block hit audio
		audio.Play ();																			//play the audio clip above
		renderer.material.color = colorHited;								//change the color of the blech when hited
		
		if (blockLives <= 0) {																//check if the block lives are 0
		
			scriptGameManager.gameScore += scoreBlock;		//give score after block is killed
			
			audio.PlayClipAtPoint (audioBlockExplosion, transform.position);								//play the full length of the audio explosion
			Instantiate (particleExplosionBlock, transform.position, transform.rotation);			//play particle explosion
			BlockReset ();																		//reset the block
		
		}
	
	}
	
	if (other.transform.tag == "player") {									//compare collided object tag
	
		blockLives -=1;																		//subtract -1 of the block lives on every collision
		
		audio.clip = audioBlockHit;													//assign audio clip to block hit audio
		audio.Play ();																			//play the audio clip above
		renderer.material.color = colorHited;								//change the color of the blech when hited
		
		if (blockLives <= 0) {																//check if the block lives are 0
		
			audio.PlayClipAtPoint (audioBlockExplosion, transform.position);								//play the full length of the audio explosion
			Instantiate (particleExplosionBlock, transform.position, transform.rotation);			//play particle explosion
			BlockReset ();																		//reset the block
		
		}
	
	}
	
	if (other.transform.tag == "shield") {									//compare collided object tag
	
		blockLives -= 2;																		//subtract -1 of the block lives on every collision
		renderer.material.color = colorHited;
		
		if (blockLives <= 0) {																//check if the block lives are 0
		
			audio.PlayClipAtPoint (audioBlockExplosion, transform.position);								//play the full length of the audio explosion
			Instantiate (particleExplosionBlock, transform.position, transform.rotation);			//play particle explosion
			BlockReset ();																		//reset the block
		
		}
	
	}

}

//reset block to top position and give him a random X and Y position
function BlockReset () {

	transform.position.y = 7;																	//move the object back to top
	transform.position.x = Random.Range (-7.5, 7.5);					//give the object random X position
	renderer.material.color = colorOriginal;										//geve the original color on reset
	blockLives = blockLivesReset;															//give the original lives value on reset

}