#pragma strict
//Credits Script

//Inspector variables

//Private variables

function Start () {

}

function Update () {

}

function OnGUI () {
	//create credits
	GUI.Box (Rect (Screen.width / 2 - 50, Screen.height / 2 - 120, 100, 50), "Credits");
	GUI.Label (Rect (Screen.width / 2 - 43, Screen.height / 2 - 100, 100, 20), "All done by me ;p");
	if (GUI.Button (Rect (Screen.width / 2 - 50, Screen.height / 2 - 60, 100, 20), "Main Menu")) {
		Application.LoadLevel ("sceneScreenMainMenu");
	}
}