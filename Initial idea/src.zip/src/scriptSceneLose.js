#pragma strict
//Lose Scene Script

//Inspector variables

//Private variables

function Start () {

}

function Update () {

}

function OnGUI () {
	//GUI Group with Box the same dimentions as the group, buttons for main menu, restart, score
	GUI.BeginGroup (Rect (Screen.width / 2 - 130, Screen.height / 2 - 100, 260, 200));
	GUI.Box (Rect (0, 0, 260, 100), "YOU LOSE!!!");
	GUI.Label (Rect (25, 35, 100, 20), "Level Score: " + PlayerPrefs.GetInt ("SCORE"));
	if (GUI.Button (Rect (50, 105, 75, 30), "Main Menu")) {					//load the main menu - if clicked betwen levels start form level1 after the 3 levesls start form level1
		Application.LoadLevel ("sceneScreenMainMenu");
	}
	
	if (GUI.Button (Rect (130, 105, 75, 30), "Restart")) {								//restart the level that was play
		Application.LoadLevel (PlayerPrefs.GetInt ("LEVELS") -1);				//subtract -1 from the number saved in PlayerPrefs LEVELS to play last played level (managet by index in buld settings)
	}
	
	GUI.EndGroup ();
}