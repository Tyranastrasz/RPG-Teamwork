#pragma strict
//Load Scene Script

//Inspector variables

//Private variables

function Start () {

}

function Update () {
	
	if (Input.GetKeyDown ("space")) {									//check if space is pressed
		Application.LoadLevel (PlayerPrefs.GetInt ("LEVELS"));				//load level1
		// Application.LoadLevel (Application.loadedLevel -1);
		// Debug.Log (Application.loadedLevel -1);
	}
	
	ScreenTime ();
	
}

function OnGUI () {
	//create GUI Group for instructions - controlss, picups  and win and lose setatements
	GUI.BeginGroup (Rect (Screen.width / 2 - 150, Screen.height / 2 - 175, 300, 400));
	GUI.Box (Rect (0, 0, 300, 350), "Instructions:");
	GUI.Label (Rect (20, 40, 300, 20), "Move the Ship: - Use Arrow Keys.");
	GUI.Label (Rect (20, 60, 300, 20), "Shoot: - Use Space Key (Default - Single Shot).");
	GUI.Label (Rect (20, 80, 300, 20), "Activate Shield: - Use C - key.");
	GUI.Label (Rect (20, 120, 300, 20), "Picups:");
	GUI.Label (Rect (20, 140, 300, 20), "Shot Double: - Soot two bullets.");
	GUI.Label (Rect (20, 160, 300, 20), "Shot Triple: - Soot three bullet - spredshot.");
	GUI.Label (Rect (20, 180, 300, 20), "Shield: - Add One shield to Ship Shields.");
	GUI.Label (Rect (20, 200, 300, 20), "*If you are hit by enemy - lose the shot picups.");
	GUI.Label (Rect (20, 240, 300, 20), "Win - Lose:");
	GUI.Label (Rect (20, 260, 300, 20), "Win - Survive till the time ends.");
	GUI.Label (Rect (20, 280, 300, 20), "Lose - Die before time ends.");
	GUI.Label (Rect (50, 320, 300, 20), "Press Space to Skip this Screen");
	
	if (GUI.Button (Rect (100, 365, 100, 30), "Back")) {							//button to go back to main menu
		Application.LoadLevel ("sceneScreenMainMenu");
	}
	
	GUI.EndGroup ();
}

function ScreenTime () {												//wait time then load level1
	yield WaitForSeconds (5.0);
	Application.LoadLevel (PlayerPrefs.GetInt ("LEVELS"));
}