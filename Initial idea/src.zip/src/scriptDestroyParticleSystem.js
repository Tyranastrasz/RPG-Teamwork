#pragma strict
//Destroy ParticleSystem Script

//Inspector variables

//Private variables

function Start () {

	Destroy (gameObject, particleSystem.duration);

}