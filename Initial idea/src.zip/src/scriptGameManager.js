#pragma strict
//Game Manager Script

//Inspector variables
var gameTime : int = 15;											//time the player need to be alive to continue to the next level
static var gameScore : int = 0;								//contains the score -  static variable can be acces easy in othe scripts by just tiping scriptGameManger.gameScore
var playerObj : GameObject;									//player game object - for acces to his componets and scripts
var asteroidObj : GameObject;								//asteroid game object - for acces to his componets and scripts
var blockObj : GameObject;									//block game object - for acces to his componets and scripts

//Private variables
private var currLevel : int;											//the value for the number of the current level in buld settings
private var playerLives : int;										//declare variable to hold the information from the accessed object
private var playerShields : int;									//declare variable to hold the information from the accessed object
private var playerShots : String;								//declare variable to hold the information from the accessed object

function Awake () {
	gameScore = 0;												//reset score on loading before Start () and Update ()
	currLevel = Application.loadedLevel;		//assign currLevel to Application.loadedLevel which is the number of the current loading level
}

function Start () {

	InvokeRepeating ("CountDown", 1.0, 1.0);					//invoke / call the function every second 1 time in the second
	
}

function Update () {
	
	playerLives = playerObj.transform.GetComponent (scriptPlayer).lives;								//get the number of lives from player
	playerShields = playerObj.transform.GetComponent (scriptPlayer).shieldsNum;			//get the number of shields form player
	playerShots = playerObj.transform.GetComponent (scriptPlayer).shotName;					//get the number of collected shots from player
	
	GameWin ();						//call the function for win condition
	GameLose ();						//call the function for lose condition

}

//cont downt the remainig time of the level
function CountDown () {

	if (--gameTime <= 0) {															//subtract -1 form gameTime and check if its 0
	
		CancelInvoke ("CountDown");										//cancel the invoke of the function	
	
	}

}

//game GUD
function OnGUI () {

	//GUI Group for the - lives, shields and picup shots
	GUI.BeginGroup (Rect (10, 10, 100, 100));											//create a group in the top left corner
	GUI.Box (Rect (0, 0, 100, 100), "HUD");													//make the box the same dimentions as the Group
	GUI.color = Color.green;
	if (playerLives <= 0 ) {																						//if player lives are 0 display below label in red
	
		GUI.color = Color.red;
	
	}
	GUI.Label (Rect (10, 25, 50, 20), "Lives: " + playerLives);					//display player lives
	if (playerShields <= 0) {																					//if player shields are 0 display below label in red
	
		GUI.color = Color.red;
	
	}
	else {																													//if player shields are not 0 display below label in green
	
		GUI.color = Color.green;
	
	}
	GUI.Label (Rect (10, 45, 100, 20), "Shields: " + playerShields);		//display player shields
	switch (playerShots) {																					//check whic picup currently is active and displayit in different color
	
		case "Single":
			GUI.color = Color.green;
			break;
			
		case "Double":
			GUI.color = Color.yellow;
			break;
			
		case "Triple":
			GUI.color = Color.red;
			break;
			
		default :
			GUI.color = Color.green;
			break;
	
	}
	GUI.Label (Rect (10, 65, 100, 20), "Shot: " + playerShots);				//display player shots

	GUI.EndGroup ();																							//end the group
	
	//GUI Group for the countdown time
	GUI.BeginGroup ( Rect (Screen.width / 2 - 50, 10, 100, 35));			//create group in the center on the screen in X and -10 pixels of the screen in Y
	GUI.Box (Rect (0, 0, 100, 35), "");																//make the box the same dimentions as the Group
	if (gameTime <= 10) {																					//change color of below label to red if the time is 10 or less
	
		GUI.color = Color.red;
	
	}
	GUI.Label (Rect (25, 5, 50, 20), "Time: " + gameTime);						//display the countdown time
	
	GUI.EndGroup ();																							//end the group
	
	
	//GUI Group for score display
	GUI.BeginGroup (Rect (Screen.width / 2 + 350, 10, 150, 35));		//create group in the top right corner of the creen
	GUI.Box (Rect (0, 0, 150, 35), "");																//make the box the same dimentions as the Group
	GUI.color = Color.white;																				//change the color of the below label to white
	GUI.Label (Rect (20, 5, 110, 20), "Score: " + gameScore);					//display the score
	
	
	GUI.EndGroup ();
	
	if (gameTime <= 0) {																						//check if the game time is 0
	
		GUI.Label (Rect (Screen.width / 2 - 25, Screen.height / 2 - 10, 100, 20), "YOU WIN");				//display toy win message
	
	}
	
	if (playerLives <= 0) {																						//check if player lives are 0
	
		GUI.Label (Rect (Screen.width / 2 - 25, Screen.height / 2 - 10, 100, 20), "GAME OVER");		//display game over message
	
	}

}

//if game timer = 0 you win the game and go to win screen
function GameWin () {

	if (gameTime <= 0) {																//check if the game time is 0
	
		PlayerPrefs.SetInt ("LEVELS", currLevel + 1);				//add +1 to the current level number so it can be used to load the next level
		PlayerPrefs.SetInt ("SCORE", gameScore);					//pass the score value of the level
		//playerObj.transform.GetComponent (scriptPlayer).collider.enabled = false;			//disable player collider
		//yield WaitForSeconds (2);												//wait for 2 seconds
		Application.LoadLevel ("sceneScreenWin");				//load win screen
		//playerObj.transform.GetComponent (scriptPlayer).collider.enabled = true;				//enable player collider
	
	}

}

//if player lives = 0 before game time is over you lose and go to lose screen
function GameLose () {

	if (playerLives <= 0) {															//check if player lives are 0
	
		PlayerPrefs.SetInt ("LEVELS", currLevel + 1);			//add +1 to the current level so ut can be used in lose scene by subtract -1 to resetart current level
		PlayerPrefs.SetInt ("SCORE", gameScore);				//pass the score value of the level
		//yield WaitForSeconds (2.0);										//wait for 2 seconds
		Application.LoadLevel ("sceneScreenLose");			//load lose screen
	
	}

}