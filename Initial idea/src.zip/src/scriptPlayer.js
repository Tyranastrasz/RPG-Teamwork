#pragma strict
//Player Script

//Inspector variables
var lives : int = 3;													//lives of the player
var moveSpeedHor : float = 5.0;					//movement speed for Horizontal axis - X axis in units per second
var moveSpeedVert : float = 5.0;					//movement speed for Vertical axis - Y axis in units per second
var shieldMesh : Transform;							//shield object for instantiate
var bulletMesh : Transform;							//bullet object for instantiate
var bulletSocketSungle : Transform;				//single socket for fire position
var bulletSocketDouble : Transform[];			//multyple bullet sockets
var bulletSocketTriple : Transform[];			//multyple bullet sockets
var shieldsNum : int = 1;									//number of shields
var shotName : String = "Single Shot";			//the name of the shot start with default SIngle ana 
var originalColor : Color;									//original color of the player ship
var audioShots : AudioClip [];							//array of audio clips for laser shots
var audioSchieldOn : AudioClip;					//audio clip when player activate shield
var audioPicupCollected : AudioClip;			//audio clip when player collect picup
var audioExplosion : AudioClip;						//audio clip when play is destroyed
var audioEnemyHit : AudioClip;						//audio clip when play is hited by enemy
var particleExplosion : Transform;					//explosion when player is destroyed

//Private variables
private var normalShot : boolean = true;						//normal shooting
private var doubleShot : boolean= false;						//double shooting
private var tripleShot : boolean = false;						//triple shooting
private var shotType : boolean = normalShot;			//shot type assign to normal so it can be uset from the start of the game
private var shieldOn : boolean = false;							//check of the shield is active
private var canShoot : boolean = true;							//allow the player to shoot
private var playerDead : boolean = false;						//if player is dead

function Start () {
	
}

function Update () {

	//move player on X and Y axis with arrow keys
	transform.Translate (Input.GetAxis("Horizontal") * moveSpeedHor * Time.deltaTime, Input.GetAxis ("Vertical") * moveSpeedVert * Time.deltaTime, 0);
	
	//constrai the movement of the object - for one resolution with no moving camera
	transform.position.x = Mathf.Clamp (transform.position.x, -7.5, 7.5);
	transform.position.y = Mathf.Clamp (transform.position.y, -5.5, 5.5);
	
	//shoot bullet when press 'space'
	if (Input.GetKeyDown ("space") && canShoot == true) {
		
		switch (shotType) {								//check which shotType is true
		
			case normalShot :								//if normalShot type is true do the followin
				
				Instantiate (bulletMesh, bulletSocketSungle.transform.position, bulletSocketSungle.transform.rotation);							//isntantiate bullet from selected child bullet socket position
				audio.clip = audioShots [0];		//assign audio clip to the audio for the first shot
				audio.Play ();									//play the above audio clip
				
				break;												//break from switch
			
			case doubleShot :								//if doubleShot type is true do the followin
			
				Instantiate (bulletMesh, bulletSocketDouble[0].transform.position, bulletSocketDouble[0].transform.rotation);				//isntantiate bullet from selected child bullet socket position
				Instantiate (bulletMesh, bulletSocketDouble[1].transform.position, bulletSocketDouble[1].transform.rotation);				//isntantiate bullet from selected child bullet socket position
				audio.clip = audioShots [1];
				audio.Play ();
				
				break;												//break from switch
				
			case tripleShot :									//if tripleShot type is true do the followin
			
				Instantiate (bulletMesh, bulletSocketTriple[0].transform.position, bulletSocketTriple[0].transform.rotation);						//isntantiate bullet from selected child bullet socket position
				Instantiate (bulletMesh, bulletSocketTriple[1].transform.position, bulletSocketTriple[1].transform.rotation);						//isntantiate bullet from selected child bullet socket position
				Instantiate (bulletMesh, bulletSocketTriple[2].transform.position, bulletSocketTriple[2].transform.rotation);						//isntantiate bullet from selected child bullet socket position
				audio.clip = audioShots [2];
				audio.Play ();
				
				break;												//break from switch
				
			default :												//no default
				break;
		
		}
	
	}
	
	//create shield in the same location as the player ship
	if (Input.GetKeyDown ('c')) {
	
		if (shieldOn == false && shieldsNum > 0) {								//check if the shield is of and if there are ani shields avable
		
		var shield = Instantiate (shieldMesh, this.transform.position, this.transform.rotation);					//instantiate shield copy as variables so it can be parented to the player
		shield.transform.parent = transform;										//make instantiated object child to this game object
		shieldOn = true;																				//make shield active
		
		audio.clip = audioSchieldOn;														//assign audio clip to shield on audio
		audio.Play ();																					//play the above audio clip
		
		}
	
	}
	
	ShieldDestroy ();			//remove from the shieldsNum
	
	if (!playerDead && lives <= 0) {				//check if player is not dead and if his lovesh are 0 - because of the check and the reset in the if statemen function is called only once
	
		ShipDestroy ();										//call the function
		playerDead = true;									//make playerDead to true so it cannot comfirm the if statemen again
	
	}
	
}

function OnTriggerEnter (other : Collider) {					//check for collisions

	if (other.transform.tag == "asteroid") {						//check collided object tag
	
		lives -= 1;																			//subtract -1 live
		shotType = normalShot;												//if player is hit assign shotType to normal shot
		shotName = "Single";													//the name of the shot after player is hited
		audio.clip = audioEnemyHit;										//assign audio clip to picup enemy hit
		audio.Play ();																	//play the above audio clip
		renderer.material.color = Color.yellow;					//change color to yelow
		yield WaitForSeconds (0.2);										//wait for time 
		renderer.material.color = originalColor;					//change color back to original color
	
	}
	
	if (other.transform.tag == "block") {								//check collided object tag
	
		lives -=1;																			//subtract -1 live
		shotType = normalShot;												//if player is hit assign shotType to normal shot
		shotName = "Single";													//the name of the shot after player is hited
		audio.clip = audioEnemyHit;										//assign audio clip to picup enemy hit
		audio.Play ();																	//play the above audio clip
		renderer.material.color = Color.yellow;					//change color to yelow
		yield WaitForSeconds (0.2);										//wait for time 
		renderer.material.color = originalColor;					//change color back to original color
	
	}
	
	if (other.transform.tag == "picupDouble") {				//check collided object tag
	
		//if picupDouble collected use double shot and disable other shots
		normalShot = false;
		doubleShot = true;
		tripleShot = false;
		shotType = doubleShot;												//assign shotType to double shot
		shotName = "Double";													//the name of the picuped shot
		
		audio.PlayClipAtPoint (audioPicupCollected, transform.position);			//play picup audio full length
	
	}
	
	if (other.transform.tag == "picupTriple") {					//check collided object tag
	
		//if picupTriple collected use double shot and disable other shots
		normalShot = false;
		doubleShot = false;
		tripleShot = true;
		shotType = tripleShot;													//assign shotType to triple shot
		shotName = "Triple";														//the name of the picuped shot
		
		audio.PlayClipAtPoint (audioPicupCollected, transform.position);			//play picup audio full length
	
	}
	
	if (other.transform.tag == "picupShield") {					//check collided object tag
	
		shieldsNum += 1;															//add + 1 shield to the shields 
		
		audio.PlayClipAtPoint (audioPicupCollected, transform.position);			//play picup audio full length
	
	}

}

function ShieldDestroy () {													//subtract form shieldsNum when shield is destroyed

	var shieldDestroyed = shieldMesh.transform.GetComponent (scriptShield).shieldHits;			//assign a variable  to  check the number of hits that shield can take
	
	if (shieldDestroyed <= 0) {												//check if the number of hits is 0
	
		shieldsNum -= 1;															//subtract -1 from the number of shields
		shieldOn = false;																//make shield inactive
	
	}

}

function ShipDestroy () {														//destroy player ship if lives get 0																//check if the lives are 0
	
		playerDead = true;
		audio.PlayClipAtPoint (audioExplosion, transform.position);							//play explosion audio full length even if the object is destroyed
		Instantiate (particleExplosion, transform.position, transform.rotation);		//play particle exposion
		
		canShoot = false;													//stop player from shooting
		renderer.enabled = false;										//stop rendering object
		collider.enabled = false;										//disable the collider of the object
}
















