#pragma strict
//Picup SpawnManager Script

//Inspector variables
var picupSpeed : float = 5.0;							//picup movement speed - units per second
var waitTimeRandMin : float = 2.0;				//minimum reset time for picup
var waitTimeRandMax : float = 5.0;				//maximum reset time for picup

//Private variables
var shouldMove : boolean = false;				//if the picup should move

function Start () {

	transform.position.x = Random.Range (-7.5, 7.5);																	//give random x position on the start of the game
	yield WaitForSeconds (Random.Range (waitTimeRandMin, waitTimeRandMax));			//radnom wait time befor picup start move
	shouldMove = true;																															//let the picup move

}

function Update () {

	//move picup down on Y
	if (shouldMove) {																												//check if picup should move
		
		transform.Translate (Vector3.down * picupSpeed * Time.deltaTime);			//move the picup in Y
	
	}
	
	//reset picup position from bottom to top on Y
	if (transform.position.y <= -7 && shouldMove == true ) {										//check of the picup is in his reset position and should he move
		
		shouldMove = false;																										//stop the picup movement and let him stai in his reset position
		PicupReset ();																													//call picup reset
		
	
	}
	
}

function OnTriggerEnter (other : Collider) {						//check for collision
	
	if (other.transform.tag == "player") {								//compare collided object tag
	
		this.transform.position.y = -7;										//if collided make picup position equal to -7 on Y
	
	}

}

function PicupReset () {

	//wait for tme then reset 
	
		yield WaitForSeconds (Random.Range (waitTimeRandMin, waitTimeRandMax));				//wait for random time to reset picup to his up - Y position
	
		transform.position.y = 7;																														//reset picup to his up - Y position
		transform.position.x = Random.Range (-7.5, 7.5);																		//give the picup random X position
		shouldMove = true;																																//let the picup move
	
}