#pragma strict
//Asteroid Script

//Inspector variables
var asteroidSpeed : float = 5.0;											//asteroid speed - units per second
var audioAsteroidExplosion : AudioClip;							//explosion audio
var particleExplosionAsteroid : Transform;						//explosion particle system
var scoreAsteroid : int = 100;												//when asteroid destroyed give score points

//Private variables

function Start () {

	transform.position.x = Random.Range (-7.5, 7.5);				//call before Update() and give the object random X position

}

function Update () {

	//move the asteroid down in Y
	transform.Translate (Vector3.down * asteroidSpeed * Time.deltaTime);
	
	//reset asteroid from top and bottom position outside the creen
	if (transform.position.y <= -7) {													//check if the object position is past botom position
	
		AsteroidResset();
	
	}

}

function OnTriggerEnter (other : Collider) {									//check for collision

	if (other.transform.tag == "bullet") {											//compare collided object tag
	
		scriptGameManager.gameScore += scoreAsteroid;			//give score points on collision - using static var gameScore from scriptGameManager
		
		audio.PlayClipAtPoint (audioAsteroidExplosion, transform.position);								//play the full length of the audio explosion
		Instantiate (particleExplosionAsteroid, transform.position, transform.rotation);			//play particle explosion
		AsteroidResset ();																//reset asteroid
	
	}
	
	if (other.transform.tag == "player") {								//compare collided object tag
	
		audio.PlayClipAtPoint (audioAsteroidExplosion, transform.position);								//play the full length of the audio explosion
		Instantiate (particleExplosionAsteroid, transform.position, transform.rotation);			//play particle explosion
		AsteroidResset ();																//reset asteroid
	
	}	
	
	if (other.transform.tag == "shield") {								//compare collided object tag
	
		audio.PlayClipAtPoint (audioAsteroidExplosion, transform.position);								//play the full length of the audio explosion
		Instantiate (particleExplosionAsteroid, transform.position, transform.rotation);			//play particle explosion
		AsteroidResset ();																//reset asteroid
	
	}

}

//reset asteroid to top position and give him a random X and Y position
function AsteroidResset () {

	transform.position.y = 7;																	//move the object back to top
	transform.position.x = Random.Range (-7.5, 7.5);					//give the object random X position

}