#pragma strict
//Main Menu Script

//Inspector variables

//Private variables
function Awake () {
	PlayerPrefs.SetInt ("LEVELS", 1);				//every time main menu is loaded reset LEVELS to 1 - when you complete the game or game is quit always make shure thata the game starts from lvl1
}

function Start () {

}

function Update () {

}

function OnGUI () {
	//create GUI Group in the center of the screen with Box the same dimention as tehe group and buttons to load: game, credits, home page and exit
	GUI.BeginGroup (Rect (Screen.width / 2 - 75, Screen.height / 2 - 110, 150, 220));
	GUI.Box (Rect (0, 0, 150, 220), "Main Menu");
	
	if (GUI.Button (Rect (25, 40, 100, 30), "Start Game")) {						//start the game buttons - go to load screen scene
		Application.LoadLevel ("sceneScreenLoadScreen");
	}
	
	if (GUI.Button (Rect (25, 80, 100, 30), "Credits")) {								//credits buttons - go to credits scene
		Application.LoadLevel ("sceneScreenCredits");
	}
	
	if (GUI.Button (Rect (25, 120, 100, 30), "Home Page")) {					//url button - goto google.com
		Application.OpenURL ("http://google.com");
	}
	
	if (GUI.Button (Rect (25, 160, 100, 30), "Exit")) {									//quit the game button
		Application.Quit ();
	}
	
	
	GUI.EndGroup ();
}