#pragma strict
//Shield Script

//Inspector variables
static var shieldHits : int = 2;						//number of hits that shield have befor its destroyed
var audioShieldHIt : AudioClip;					//shield hit audio

//Private variables
private var shieldHitsReset : int;					//shield hit reset variable

function Start () {

	shieldHitsReset = shieldHits;					//assign shieldHitsReset variable to shieldHits value in start so it can be suet to reset value

}

function Update () {

	//destroy shield
	if (shieldHits <= 0) {										//check if number of hits are 0
	
		shieldHits = shieldHitsReset;					//reset the shieldHits to its normal value
		Destroy (gameObject);								//destroy the shield
	
	}

}

function OnTriggerEnter (other : Collider) {														//check for collisions

	if (other.transform.tag == "asteroid") {															//compare collided object tag
	
		shieldHits -= 1;																									//subtract -1 from shieldHits
		
		audio.PlayClipAtPoint (audioShieldHIt, transform.position);					//play shield hit audio full length even if the object is destroyed

	
	}
	
	if (other.transform.tag == "block") {																	//compare collided object tag
	
		shieldHits -= 2;																									//subtract -1 from shieldHits
		
		audio.PlayClipAtPoint (audioShieldHIt, transform.position);					//play shield hit audio full length even if the object is destroyed
	
	}

}